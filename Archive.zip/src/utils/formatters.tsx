import { format, isToday, isThisMonth, isThisYear } from "date-fns";

export const formatRank = (rank: number): string => {
  return `#${rank}`;
};

export const formatPoints = (points: number): string => {
  return points.toString();
};

export const formatDate = (date: string): string => {
  return format(new Date(date), "PPP");
};

export const isPeriod = (date: string, period: string): boolean => {
  const dateObj = new Date(date);

  switch (period) {
    case "day":
      return isToday(dateObj);
    case "month":
      return isThisMonth(dateObj);
    case "year":
      return isThisYear(dateObj);
    default:
      return true;
  }
};
