export type ToastType = "success" | "error" | "info" | "warning";

export const toast = (message: string, type: ToastType = "info") => {
  // Simple implementation, in a real app you would use a toast library
  console.log(`[${type}]: ${message}`);
  alert(`${message}`);
};
