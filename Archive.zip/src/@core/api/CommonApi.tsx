import Request from ".";
import { ApiRoutes } from "../constants";

// Define a type for the data parameter

export const getLeaderboard = async (data) => {
  const res = await Request.post(ApiRoutes.GETLEADERBOARD, data);
  return res;
};

export const recalculateLeaderboard = async () => {
  const res = await Request.post(ApiRoutes.RECALCULATELEADERBOARD);
  return res;
};
