export const ApiRoutes = {
  API_HOSTNAME: "http://localhost:5008",
  WS_HOSTNAME: "ws://localhost:5008",
  GETLEADERBOARD: "/leaderboard",
  RECALCULATELEADERBOARD: "/recalculate",
};
