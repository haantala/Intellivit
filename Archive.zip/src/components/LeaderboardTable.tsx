"use client";
import React from "react";
import { formatRank, formatPoints } from "../utils/formatters";

interface LeaderboardTableProps {
  users;
  isLoading?: boolean;
}

const LeaderboardTable: React.FC<LeaderboardTableProps> = ({
  users,
  isLoading = false,
}) => {
  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (users.length === 0) {
    return <div className="text-center py-8 text-gray-400">No users found</div>;
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="text-left border-b border-gray-800">
            <th className="py-3 px-4 text-gray-400">ID</th>
            <th className="py-3 px-4 text-gray-400">Name</th>
            <th className="py-3 px-4 text-gray-400 text-right">Points</th>
            <th className="py-3 px-4 text-gray-400 text-right">Rank</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user, index) => (
            <tr key={index} className="transition-colors hover:bg-gray-800/50">
              <td className="py-4 px-4">{user.user_id}</td>
              <td className="py-4 px-4">{user.user.full_name}</td>
              <td className="py-4 px-4 text-right">
                {formatPoints(user.total_points)}
              </td>
              <td className="py-4 px-4 text-right">{formatRank(user.rank)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default LeaderboardTable;
