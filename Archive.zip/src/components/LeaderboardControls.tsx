"use client";
import React, { useState } from "react";
import Dropdown from "./Dropdown";
// // import Button from "./ui/Button";
// // import Input from "./ui/Input";
// // import Dropdown from "./Dropdown";

interface LeaderboardControlsProps {
  onSearch: (userId: string) => void;
  onFilterChange: (period: string) => void;
  onRecalculate: () => void;
  period: string;
  isLoading?: boolean;
}

const periods = [
  { value: "day", label: "Day" },
  { value: "month", label: "Month" },
  { value: "year", label: "Year" },
  { value: "all", label: "All Time" },
];

const LeaderboardControls: React.FC<LeaderboardControlsProps> = ({
  onSearch,
  onFilterChange,
  onRecalculate,
  period,
  isLoading = false,
}) => {
  const [userId, setUserId] = useState("");

  const handleSearch = () => {
    onSearch(userId);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Activity Leaderboard</h1>
        <button
          onClick={onRecalculate}
          disabled={isLoading}
          className="bg-gray-200 text-gray-900 hover:bg-gray-300"
        >
          {isLoading ? "Processing..." : "Recalculate"}
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-2">
          <input
            // label="User ID"
            placeholder="Enter user ID to search"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            onKeyDown={handleKeyPress}
          />
        </div>
        <div className="flex gap-2 items-end">
          <Dropdown
            label="Filter by"
            options={periods}
            value={period}
            onChange={(value) => onFilterChange(value as string)}
            className="flex-grow"
          />
          <button
            onClick={handleSearch}
            className="bg-blue-600 text-white hover:bg-blue-700"
          >
            Search
          </button>
        </div>
      </div>
    </div>
  );
};

export default LeaderboardControls;
