"use client";
import React, { useState, useEffect } from "react";
import LeaderboardControls from "./LeaderboardControls";
import LeaderboardTable from "./LeaderboardTable";
import { toast } from "@/utils/toast";
import { getLeaderboard, recalculateLeaderboard } from "@/@core/api/CommonApi";
// import LeaderboardTable from "./LeaderboardTable";
// import { getLeaderboard, recalculateLeaderboard } from "../api/leaderboard";
// import { toast } from "../utils/toast";

const Leaderboard = () => {
  const [users, setUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [period, setPeriod] = useState<string>("all");
  const [searchId, setSearchId] = useState("");

  const fetchLeaderboard = async () => {
    setIsLoading(true);
    try {
      const res = await getLeaderboard({ period, searchId });
      console.log("====================================");
      console.log(res);
      console.log("====================================");
      if (res.leaderboard) {
        const data = res.leaderboard;

        setUsers(data);
      }
    } catch (error) {
      console.error("Error fetching leaderboard:", error);
      toast("Failed to load leaderboard", "error");
    } finally {
      setIsLoading(false);
    }
    setIsLoading(false); // fallback to remove loader
  };

  useEffect(() => {
    fetchLeaderboard();
  }, [period]);

  const handleSearch = (userId: string) => {
    setSearchId(userId);
    fetchLeaderboard();
  };

  const handleFilterChange = (newPeriod: string) => {
    setPeriod(newPeriod);
  };

  const handleRecalculate = async () => {
    setIsLoading(true);
    try {
      const success = await recalculateLeaderboard();
      if (success) {
        toast("Leaderboard recalculated successfully", "success");
        fetchLeaderboard();
      } else {
        toast("Failed to recalculate leaderboard", "error");
      }
    } catch (error) {
      console.error("Error recalculating leaderboard:", error);
      toast("Failed to recalculate leaderboard", "error");
    } finally {
      setIsLoading(false);
    }
    setIsLoading(false); // fallback
  };

  return (
    <div className="space-y-6">
      <LeaderboardControls
        onSearch={handleSearch}
        onFilterChange={handleFilterChange}
        onRecalculate={handleRecalculate}
        period={period}
        isLoading={isLoading}
      />
      <LeaderboardTable users={users} isLoading={isLoading} />
    </div>
  );
};

export default Leaderboard;
